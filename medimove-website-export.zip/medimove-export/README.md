# MediMove Website - Production Ready

A professional, conversion-optimized website for MediMove Transportation & Homecare services.

## 📁 Project Structure

```
medimove-website/
├── index.html              # Main HTML file
├── favicon.ico             # Website favicon
├── README.md              # This file
└── assets/
    ├── css/
    │   └── main.css       # Minified CSS styles
    ├── js/
    │   └── main.js        # Minified JavaScript
    └── images/
        └── medimove-logo.png  # Company logo
```

## 🚀 Quick Start

### Local Development
1. Download and extract the project files
2. Open `index.html` in any modern web browser
3. The website will run locally without any server requirements

### Testing Locally
- Simply double-click `index.html` or
- Right-click → "Open with" → Your preferred browser
- All assets are properly linked with relative paths

## 🌐 Deployment Options

### Option 1: GitHub Pages

1. **Create a new repository on GitHub**
   ```bash
   # Create new repo on GitHub, then:
   git init
   git add .
   git commit -m "Initial commit - MediMove website"
   git branch -M main
   git remote add origin https://github.com/yourusername/medimove-website.git
   git push -u origin main
   ```

2. **Enable GitHub Pages**
   - Go to repository Settings
   - Scroll to "Pages" section
   - Source: Deploy from a branch
   - Branch: main / (root)
   - Click Save

3. **Access your site**
   - URL: `https://yourusername.github.io/medimove-website`
   - Updates automatically when you push changes

### Option 2: Netlify

#### Method A: Drag & Drop
1. Go to [netlify.com](https://netlify.com)
2. Sign up/login
3. Drag the entire project folder to the deploy area
4. Get instant URL: `https://random-name.netlify.app`

#### Method B: Git Integration
1. Push code to GitHub (see GitHub Pages steps 1)
2. Connect Netlify to your GitHub repository
3. Build settings:
   - Build command: (leave empty)
   - Publish directory: `/` (root)
4. Deploy automatically on every push

### Option 3: Vercel

1. Install Vercel CLI: `npm i -g vercel`
2. In project directory: `vercel`
3. Follow prompts
4. Get instant deployment URL

### Option 4: Traditional Web Hosting

1. **Upload via FTP/cPanel**
   - Upload all files to your web hosting public_html folder
   - Maintain the folder structure
   - Access via your domain

2. **Supported hosting providers**
   - Any shared hosting (GoDaddy, Bluehost, etc.)
   - VPS or dedicated servers
   - CDN services (Cloudflare Pages, AWS S3)

## 🔧 Customization

### Updating Content
- **Contact Information**: Edit phone numbers and email in `assets/js/main.js`
- **Services**: Modify service descriptions in the JavaScript file
- **Styling**: Update colors and fonts in `assets/css/main.css`

### Adding Analytics
Add tracking code before closing `</head>` tag in `index.html`:

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'GA_MEASUREMENT_ID');
</script>
```

### Custom Domain Setup

#### GitHub Pages
1. Add `CNAME` file with your domain
2. Configure DNS A records to GitHub's IPs:
   - 185.199.108.153
   - 185.199.109.153
   - 185.199.110.153
   - 185.199.111.153

#### Netlify
1. Go to Domain settings in Netlify dashboard
2. Add custom domain
3. Update DNS to point to Netlify

## 📱 Features

- **Responsive Design**: Works on all devices
- **Performance Optimized**: Minified CSS/JS, optimized images
- **SEO Ready**: Proper meta tags and structure
- **Accessibility**: WCAG compliant design
- **Contact Forms**: Functional contact and waitlist forms
- **Professional Design**: Healthcare-appropriate styling

## 🛠 Technical Details

- **Framework**: React (compiled to static files)
- **Styling**: Tailwind CSS (compiled and minified)
- **Icons**: Lucide React icons (bundled)
- **Performance**: 
  - Minified assets
  - Optimized images
  - Efficient CSS/JS bundling

## 📞 Support

For technical issues or customization requests:
- Review the code structure in `assets/js/main.js`
- CSS modifications in `assets/css/main.css`
- HTML structure in `index.html`

## 🔄 Updates

To update the website:
1. Make changes to source files
2. Test locally by opening `index.html`
3. Upload/push changes to your hosting platform
4. Changes will be live immediately

## 📋 Browser Compatibility

- Chrome 60+
- Firefox 60+
- Safari 12+
- Edge 79+
- Mobile browsers (iOS Safari, Chrome Mobile)

## 🚨 Important Notes

- All file paths use relative URLs for maximum compatibility
- No server-side processing required
- Forms are client-side (integrate with your preferred form handler)
- Images are optimized for web delivery
- CSS and JavaScript are production-minified

---

**MediMove Website** - Professional healthcare services presentation
Built with modern web technologies for optimal performance and user experience.

